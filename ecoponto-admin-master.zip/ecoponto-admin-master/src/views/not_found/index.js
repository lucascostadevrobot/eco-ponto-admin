import React from 'react';


export default class NotFound extends React.Component {
    render() {
        return (<div style={{ margin: '20px' }}><h4>Página não encontrada!</h4></div>)
    }



}